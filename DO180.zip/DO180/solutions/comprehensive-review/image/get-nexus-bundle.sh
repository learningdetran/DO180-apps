#!/bin/bash
curl -s -O http://content.example.com/ocp4.0/x86_64/installers/nexus-2.14.3-02-bundle.tar.gz
